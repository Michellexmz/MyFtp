
document.write('<table class="footer" border="0">')

document.write('<tr>')

document.write('  <td valign="top" align="left">Copyright &copy; 2004-2016  <a href="http://www.qos.ch/">QOS.ch</a></td>')

//document.write('  <td rowspan="2">');
//document.write('    <a href="http://twitter.com/qos_ch">');
//document.write('      <img alt="Follow @qos_ch" src="images/follow_us.png" />');
//document.write('    </a>');
//document.write('  </td>');


document.write('</tr>')

AAT = '@'
DOOTT = '.'
document.write('<tr>')
document.write('<td align="left" colspan="1">')
document.write('We are actively looking for volunteers to proofread the documentation. Please send your corrections or suggestions for improvement to "corrections' + AAT +'qos'+DOOTT+'ch". See also the <a href="http://articles.qos.ch/contributing.html">instructions for contributors</a>.');
document.write('</td>')
document.write('</tr>')


document.write('</table>')


